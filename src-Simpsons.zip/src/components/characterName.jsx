import React, { Component } from 'react'
class CharacterName extends Component {
  render() { 
    return (<h2>{this.props.name}</h2>);
  }
}
 
export default CharacterName;