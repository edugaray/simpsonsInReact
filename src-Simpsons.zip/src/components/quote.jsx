import React, { Component } from 'react'
class Quote extends Component {
  render() {
    return (<p>{this.props.quote}</p> );
  }
}

export default Quote;